package controller.runnables;

/**
 * The test for Sepia Button.
 */
public class SepiaButtonActionTest extends AbstractButtonActionTest {

  public SepiaButtonActionTest() {
    super("Sepia Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}