package controller.runnables;

/**
 * The test for Value Button.
 */
public class ValueButtonActionTest extends AbstractButtonActionTest {

  /**
   * Constructs a button test.
   */
  public ValueButtonActionTest() {
    super("Value Button",
            "added listeners\nCommand: asked: Name the modified version of the image:\n");
  }
}