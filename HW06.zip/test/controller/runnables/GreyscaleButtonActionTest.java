package controller.runnables;

/**
 * The test for Greyscale Button.
 */
public class GreyscaleButtonActionTest extends AbstractButtonActionTest {

  /**
   * Constructs a button test.
   */
  public GreyscaleButtonActionTest() {
    super("Greyscale Button",
            "added listeners\nCommand: asked: Name the modified version of the image:\n");
  }
}