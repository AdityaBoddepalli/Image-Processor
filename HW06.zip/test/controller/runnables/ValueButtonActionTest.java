package controller.runnables;

/**
 * The test for Value Button.
 */
public class ValueButtonActionTest extends AbstractButtonActionTest {

  public ValueButtonActionTest() {
    super("Value Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}