package controller.runnables;

/**
 * The test for Greyscale Button.
 */
public class GreyscaleButtonActionTest extends AbstractButtonActionTest {

  public GreyscaleButtonActionTest() {
    super("Greyscale Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}