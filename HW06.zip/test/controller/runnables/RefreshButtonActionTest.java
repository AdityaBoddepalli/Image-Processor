package controller.runnables;

/**
 * The test for Refresh Button.
 */
public class RefreshButtonActionTest extends AbstractButtonActionTest {

  public RefreshButtonActionTest() {
    super("Refresh GUI Button",
            "refreshed view\n");
  }
}