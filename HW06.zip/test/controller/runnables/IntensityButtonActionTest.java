package controller.runnables;

/**
 * The test for Intensity Button.
 */
public class IntensityButtonActionTest extends AbstractButtonActionTest {

  public IntensityButtonActionTest() {
    super("Intensity Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}