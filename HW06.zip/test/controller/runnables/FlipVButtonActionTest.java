package controller.runnables;

/**
 * The test for Flip Vertical Button.
 */
public class FlipVButtonActionTest extends AbstractButtonActionTest {

  public FlipVButtonActionTest() {
    super("Flip Vertical Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}