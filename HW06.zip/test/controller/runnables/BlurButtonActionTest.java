package controller.runnables;

/**
 * The test for Blur Button.
 */
public class BlurButtonActionTest extends AbstractButtonActionTest {

  public BlurButtonActionTest() {
    super("Blur Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}