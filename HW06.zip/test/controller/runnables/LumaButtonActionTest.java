package controller.runnables;

/**
 * The test for Luma Button.
 */
public class LumaButtonActionTest extends AbstractButtonActionTest {

  public LumaButtonActionTest() {
    super("Luma Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}