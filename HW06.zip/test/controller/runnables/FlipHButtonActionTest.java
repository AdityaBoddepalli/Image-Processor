package controller.runnables;

/**
 * The test for Flip Horizontal Button.
 */
public class FlipHButtonActionTest extends AbstractButtonActionTest {

  public FlipHButtonActionTest() {
    super("Flip Horizontal Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}