package controller.runnables;

/**
 * The test for Brighten Button.
 */
public class BrightenButtonActionTest extends AbstractButtonActionTest {

  public BrightenButtonActionTest() {
    super("Brighten Button",
            "Command: asked: Enter the brightening factor\n");
  }
}