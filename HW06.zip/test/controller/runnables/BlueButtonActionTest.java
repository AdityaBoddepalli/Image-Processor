package controller.runnables;

/**
 * The test for Blue Button.
 */
public class BlueButtonActionTest extends AbstractButtonActionTest {

  public BlueButtonActionTest() {
    super("Blue Component Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}