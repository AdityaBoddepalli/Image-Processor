package controller.runnables;

/**
 * The test for Green Button.
 */
public class GreenButtonActionTest extends AbstractButtonActionTest {

  public GreenButtonActionTest() {
    super("Green Component Button",
            "Command: asked: Name the modified version of the image:\n");
  }
}