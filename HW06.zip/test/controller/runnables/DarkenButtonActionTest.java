package controller.runnables;

/**
 * The test for Darken Button.
 */
public class DarkenButtonActionTest extends AbstractButtonActionTest {

  public DarkenButtonActionTest() {
    super("Darken Button",
            "Command: asked: Enter the darkening factor\n");
  }
}