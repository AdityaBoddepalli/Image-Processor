package controller.runnables;

/**
 * The test for Open Button.
 */
public class OpenButtonActionTest extends AbstractButtonActionTest {

  public OpenButtonActionTest() {
    super("Open Button",
            "Command: asked: Enter the name of the image: \n");
  }
}